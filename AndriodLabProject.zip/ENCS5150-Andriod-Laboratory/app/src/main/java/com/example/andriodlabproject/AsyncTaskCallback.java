package com.example.andriodlabproject;

public interface AsyncTaskCallback {

    void onTaskComplete(boolean success);

}
